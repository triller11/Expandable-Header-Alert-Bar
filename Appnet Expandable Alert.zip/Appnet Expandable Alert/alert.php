<?php
/**
 * Plugin Name: Appnet Expandable Alert Bar
 * Description: Adds a reusable alert bar above the site header with an expandable information panel.
 * Version: 1.3.2
 * Author: Appnet
 */

if (!defined('ABSPATH')) exit;

/**
 * Default plugin settings.
 */
function appnet_fraud_alert_defaults() {
	return array(
		'enabled' => '1',
		'bar_title' => 'Important Notice',
        'bar_text' => 'Please review this important message.',
        'button_text' => 'More Info',
        'panel_title' => 'Important Notice',
        'panel_content' => "Add your expanded alert message here.",
	);
}

/**
 * Get saved settings merged with defaults.
 */
function appnet_fraud_alert_get_settings() {
	$saved = get_option('appnet_fraud_alert_settings', array());
	return wp_parse_args($saved, appnet_fraud_alert_defaults());
}

/**
 * Add settings page under Settings.
 */
function appnet_fraud_alert_add_settings_page() {
	add_options_page(
        'Expandable Alert Bar',
        'Expandable Alert Bar',
        'manage_options',
        'appnet-expandable-alert',
        'appnet_fraud_alert_render_settings_page'
    );
}
add_action('admin_menu', 'appnet_fraud_alert_add_settings_page');

/**
 * Register plugin settings.
 */
function appnet_fraud_alert_register_settings() {
	register_setting(
		'appnet_fraud_alert_group',
		'appnet_fraud_alert_settings',
		'appnet_fraud_alert_sanitize_settings'
	);
}
add_action('admin_init', 'appnet_fraud_alert_register_settings');

/**
 * Sanitize settings.
 */
function appnet_fraud_alert_sanitize_settings($input) {
	$defaults = appnet_fraud_alert_defaults();

	return array(
		'enabled' => isset($input['enabled']) ? '1' : '0',
		'bar_title' => sanitize_text_field($input['bar_title'] ?? $defaults['bar_title']),
		'bar_text' => sanitize_text_field($input['bar_text'] ?? $defaults['bar_text']),
		'button_text' => sanitize_text_field($input['button_text'] ?? $defaults['button_text']),
		'panel_title' => sanitize_text_field($input['panel_title'] ?? $defaults['panel_title']),
		'panel_content' => sanitize_textarea_field($input['panel_content'] ?? $defaults['panel_content']),
	);
}

/**
 * Render settings page.
 */
function appnet_fraud_alert_render_settings_page() {
	if (!current_user_can('manage_options')) return;

	$settings = appnet_fraud_alert_get_settings();
	?>
	<div class="wrap">
		<h1>Expandable Alert Bar</h1>

		<form method="post" action="options.php">
			<?php settings_fields('appnet_fraud_alert_group'); ?>

			<table class="form-table" role="presentation">
				<tr>
					<th scope="row">Enable Alert</th>
					<td>
						<label>
							<input type="checkbox" name="appnet_fraud_alert_settings[enabled]" value="1" <?php checked($settings['enabled'], '1'); ?>>
							Show alert bar
						</label>
					</td>
				</tr>

				<tr>
					<th scope="row">Bar Title</th>
					<td>
						<input type="text" class="regular-text" name="appnet_fraud_alert_settings[bar_title]" value="<?php echo esc_attr($settings['bar_title']); ?>">
					</td>
				</tr>

				<tr>
					<th scope="row">Bar Text</th>
					<td>
						<input type="text" class="large-text" name="appnet_fraud_alert_settings[bar_text]" value="<?php echo esc_attr($settings['bar_text']); ?>">
					</td>
				</tr>

				<tr>
					<th scope="row">Button Text</th>
					<td>
						<input type="text" class="regular-text" name="appnet_fraud_alert_settings[button_text]" value="<?php echo esc_attr($settings['button_text']); ?>">
					</td>
				</tr>

				<tr>
					<th scope="row">Panel Title</th>
					<td>
						<input type="text" class="regular-text" name="appnet_fraud_alert_settings[panel_title]" value="<?php echo esc_attr($settings['panel_title']); ?>">
					</td>
				</tr>

				<tr>
					<th scope="row">Panel Content</th>
					<td>
						<textarea class="large-text" rows="12" name="appnet_fraud_alert_settings[panel_content]"><?php echo esc_textarea($settings['panel_content']); ?></textarea>
						<p class="description">Line breaks will be preserved on the front end.</p>
					</td>
				</tr>
			</table>

			<?php submit_button(); ?>
		</form>
	</div>
	<?php
}

/**
 * Render fraud alert at the top of the site.
 */
function appnet_fraud_alert_render_frontend() {
	$settings = appnet_fraud_alert_get_settings();

	if ($settings['enabled'] !== '1') {
		return;
	}
	?>
	<div class="appnet-fraud-alert-bar" role="region" aria-label="Fraud alert">
		<strong><?php echo esc_html($settings['bar_title']); ?></strong>
		<span><?php echo esc_html($settings['bar_text']); ?></span>
		<button type="button" class="appnet-fraud-alert-toggle">
			<?php echo esc_html($settings['button_text']); ?>
		</button>
	</div>

	<div class="appnet-fraud-alert-panel" hidden>
		<div class="appnet-fraud-alert-panel-inner">
			<button type="button" class="appnet-fraud-alert-close">Close</button>

			<h2><?php echo esc_html($settings['panel_title']); ?></h2>

			<div class="appnet-fraud-alert-content">
				<?php echo wpautop(esc_html($settings['panel_content'])); ?>
			</div>
		</div>
	</div>
	<?php
}
add_action('wp_body_open', 'appnet_fraud_alert_render_frontend');

/**
 * Frontend CSS and JS.
 */
function appnet_fraud_alert_frontend_assets() {
	$settings = appnet_fraud_alert_get_settings();

	if ($settings['enabled'] !== '1') {
		return;
	}
	?>
	<style>
		.appnet-fraud-alert-bar {
			width: 100%;
			background: #111;
			color: #fff;
			padding: 12px 24px;
			font-size: 15px;
			line-height: 1.4;
			display: flex;
			align-items: center;
			justify-content: center;
			gap: 14px;
			flex-wrap: wrap;
			z-index: 100000;
			position: relative;
			box-sizing: border-box;
			text-align: center;
			overflow: hidden;
			max-height: 220px;
			transition: max-height 0.2s ease, padding 0.2s ease, opacity 0.2s ease;
		}

		.appnet-fraud-alert-bar strong {
			font-weight: 700;
		}

		.appnet-fraud-alert-toggle,
		.appnet-fraud-alert-close {
			background: #fff;
			color: #111;
			border: 0;
			padding: 7px 14px;
			cursor: pointer;
			font-weight: 600;
			border-radius: 0;
			line-height: 1.3;
		}

		.appnet-fraud-alert-toggle:hover,
		.appnet-fraud-alert-close:hover {
			opacity: 0.85;
		}

		/**
		 * When the user scrolls down, collapse the actual alert bar.
		 * This lets the header move up naturally without fake padding/margins.
		 */
		body.appnet-fraud-alert-scrolled .appnet-fraud-alert-bar {
			max-height: 0;
			padding-top: 0;
			padding-bottom: 0;
			opacity: 0;
			pointer-events: none;
		}

		.appnet-fraud-alert-panel {
			background: #fff;
			color: #111;
			padding: 40px 24px;
			border-bottom: 1px solid #ddd;
			z-index: 99998;
			position: relative;
			box-sizing: border-box;
		}

		.appnet-fraud-alert-panel-inner {
			max-width: 1100px;
			margin: 0 auto;
		}

		.appnet-fraud-alert-panel h2 {
			margin-top: 0;
			margin-bottom: 24px;
		}

		.appnet-fraud-alert-close {
			float: right;
			background: #111;
			color: #fff;
			margin-left: 20px;
			margin-bottom: 20px;
		}

		.appnet-fraud-alert-content {
			clear: both;
		}

		/**
		 * When More Info is open, hide the normal site header and page content.
		 * This creates the "replace page content" effect.
		 */
		/* body.appnet-fraud-alert-open .l-main,
		body.appnet-fraud-alert-open .l-header, */
		body.appnet-fraud-alert-open .appnet-fraud-alert-bar {
			display: none !important;
		}

		@media (max-width: 600px) {
			.appnet-fraud-alert-bar {
				display: block;
				padding: 12px 16px;
			}

			.appnet-fraud-alert-bar strong,
			.appnet-fraud-alert-bar span {
				display: block;
				margin-bottom: 8px;
			}

			body.appnet-fraud-alert-scrolled .appnet-fraud-alert-bar {
				padding-top: 0;
				padding-bottom: 0;
			}

			.appnet-fraud-alert-panel {
				padding: 30px 18px;
			}

			.appnet-fraud-alert-close {
				float: none;
				display: inline-block;
				margin: 0 0 20px 0;
			}
		}
	</style>

	<script>
		document.addEventListener('DOMContentLoaded', function () {
            const toggle = document.querySelector('.appnet-fraud-alert-toggle');
            const close = document.querySelector('.appnet-fraud-alert-close');
            const panel = document.querySelector('.appnet-fraud-alert-panel');

            if (!toggle || !close || !panel) return;

            let scrollTimer = null;

            function collapseFraudAlert() {
                document.body.classList.add('appnet-fraud-alert-scrolled');
            }

            function showFraudAlert() {
                document.body.classList.remove('appnet-fraud-alert-scrolled');
            }

            function updateFraudAlertScrollState() {
                if (document.body.classList.contains('appnet-fraud-alert-open')) {
                    return;
                }

                clearTimeout(scrollTimer);

                /*
                * Collapse only after the user has clearly moved down the page.
                * This avoids the alert rapidly opening/closing near the top.
                */
                if (window.scrollY > 80) {
                    collapseFraudAlert();
                    return;
                }

                /*
                * Only reopen when the user is truly at the top, and wait briefly
                * so it does not fight against normal scrolling momentum.
                */
                if (window.scrollY <= 0) {
                    scrollTimer = setTimeout(function () {
                        if (window.scrollY <= 0 && !document.body.classList.contains('appnet-fraud-alert-open')) {
                            showFraudAlert();
                        }
                    }, 150);
                }
            }

            updateFraudAlertScrollState();

            window.addEventListener('scroll', updateFraudAlertScrollState, { passive: true });

            toggle.addEventListener('click', function () {
                panel.hidden = false;

                document.body.classList.add('appnet-fraud-alert-open');
                document.body.classList.remove('appnet-fraud-alert-scrolled');

                window.scrollTo({ top: 0, behavior: 'auto' });
            });

            close.addEventListener('click', function () {
                panel.hidden = true;

                document.body.classList.remove('appnet-fraud-alert-open');

                updateFraudAlertScrollState();
            });
        });
	</script>
	<?php
}
add_action('wp_footer', 'appnet_fraud_alert_frontend_assets');