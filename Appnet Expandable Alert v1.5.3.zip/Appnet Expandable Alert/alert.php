<?php
/**
 * Plugin Name: Appnet Expandable Alert Bar
 * Description: Adds a reusable alert bar above the site header with an expandable information panel.
 * Version: 1.5.3
 * Author: Appnet
 */

if (!defined('ABSPATH')) exit;

/**
 * Default plugin settings.
 */
function appnet_fraud_alert_defaults() {
	return array(
		'enabled' => '1',
		'bar_title' => 'Important Notice',
		'bar_text' => 'Please review this important message.',
		'button_text' => 'More Info',
		'panel_title' => 'Important Notice',
		'panel_content' => "Add your expanded alert message here.",

		// Color settings. The hex value is always kept as a fallback, even when a site color is selected.
		'bar_background_color' => '#111111',
		'bar_background_color_source' => 'custom',
		'bar_background_color_site_color' => '',

		'bar_text_color' => '#ffffff',
		'bar_text_color_source' => 'custom',
		'bar_text_color_site_color' => '',

		'button_background_color' => '#ffffff',
		'button_background_color_source' => 'custom',
		'button_background_color_site_color' => '',

		'button_text_color' => '#111111',
		'button_text_color_source' => 'custom',
		'button_text_color_site_color' => '',

		'panel_background_color' => '#ffffff',
		'panel_background_color_source' => 'custom',
		'panel_background_color_site_color' => '',

		'panel_text_color' => '#111111',
		'panel_text_color_source' => 'custom',
		'panel_text_color_site_color' => '',

		'close_button_background_color' => '#111111',
		'close_button_background_color_source' => 'custom',
		'close_button_background_color_site_color' => '',

		'close_button_text_color' => '#ffffff',
		'close_button_text_color_source' => 'custom',
		'close_button_text_color_site_color' => '',

		'panel_border_color' => '#dddddd',
		'panel_border_color_source' => 'custom',
		'panel_border_color_site_color' => '',
	);
}

/**
 * Get saved settings merged with defaults.
 */
function appnet_fraud_alert_get_settings() {
	$saved = get_option('appnet_fraud_alert_settings', array());
	return wp_parse_args($saved, appnet_fraud_alert_defaults());
}

/**
 * Site color CSS variables used by Impreza / US Themes sites.
 *
 * These are saved as a selectable key instead of raw CSS so the setting remains safe.
 * The frontend outputs them as var(--theme-color, #fallback).
 */
function appnet_fraud_alert_site_color_options() {
	return array(
		'content_bg' => array(
			'label' => 'Content Background',
			'css_var' => '--color-content-bg',
		),
		'content_bg_alt' => array(
			'label' => 'Content Alternate Background',
			'css_var' => '--color-content-bg-alt',
		),
		'content_border' => array(
			'label' => 'Content Border',
			'css_var' => '--color-content-border',
		),
		'content_heading' => array(
			'label' => 'Content Heading',
			'css_var' => '--color-content-heading',
		),
		'content_text' => array(
			'label' => 'Content Text',
			'css_var' => '--color-content-text',
		),
		'content_primary' => array(
			'label' => 'Content Primary',
			'css_var' => '--color-content-primary',
		),
		'content_secondary' => array(
			'label' => 'Content Secondary',
			'css_var' => '--color-content-secondary',
		),
		'content_faded' => array(
			'label' => 'Content Faded',
			'css_var' => '--color-content-faded',
		),

		'alt_content_bg' => array(
			'label' => 'Alternate Content Background',
			'css_var' => '--color-alt-content-bg',
		),
		'alt_content_bg_alt' => array(
			'label' => 'Alternate Content Alternate Background',
			'css_var' => '--color-alt-content-bg-alt',
		),
		'alt_content_border' => array(
			'label' => 'Alternate Content Border',
			'css_var' => '--color-alt-content-border',
		),
		'alt_content_heading' => array(
			'label' => 'Alternate Content Heading',
			'css_var' => '--color-alt-content-heading',
		),
		'alt_content_text' => array(
			'label' => 'Alternate Content Text',
			'css_var' => '--color-alt-content-text',
		),
		'alt_content_primary' => array(
			'label' => 'Alternate Content Primary',
			'css_var' => '--color-alt-content-primary',
		),
		'alt_content_secondary' => array(
			'label' => 'Alternate Content Secondary',
			'css_var' => '--color-alt-content-secondary',
		),
		'alt_content_faded' => array(
			'label' => 'Alternate Content Faded',
			'css_var' => '--color-alt-content-faded',
		),

		'header_top_bg' => array(
			'label' => 'Header Top Background',
			'css_var' => '--color-header-top-bg',
		),
		'header_top_text' => array(
			'label' => 'Header Top Text',
			'css_var' => '--color-header-top-text',
		),
		'header_middle_bg' => array(
			'label' => 'Header Middle Background',
			'css_var' => '--color-header-middle-bg',
		),
		'header_middle_text' => array(
			'label' => 'Header Middle Text',
			'css_var' => '--color-header-middle-text',
		),
		'header_bottom_bg' => array(
			'label' => 'Header Bottom Background',
			'css_var' => '--color-header-bottom-bg',
		),
		'header_bottom_text' => array(
			'label' => 'Header Bottom Text',
			'css_var' => '--color-header-bottom-text',
		),
	);
}

/**
 * Add top-level settings page.
 */
function appnet_fraud_alert_add_settings_page() {
	add_menu_page(
		'Appnet Alert Bar',
		'Appnet Alert Bar',
		'manage_options',
		'appnet-alert-bar',
		'appnet_fraud_alert_render_settings_page',
		'dashicons-warning',
		3
	);
}
add_action('admin_menu', 'appnet_fraud_alert_add_settings_page');

/**
 * Register plugin settings.
 */
function appnet_fraud_alert_register_settings() {
	register_setting(
		'appnet_fraud_alert_group',
		'appnet_fraud_alert_settings',
		'appnet_fraud_alert_sanitize_settings'
	);
}
add_action('admin_init', 'appnet_fraud_alert_register_settings');

/**
 * Sanitize a hex color and fall back to a default if invalid.
 */
function appnet_fraud_alert_sanitize_color($value, $default) {
	$color = sanitize_hex_color($value);
	return $color ? $color : $default;
}

/**
 * Sanitize whether a field uses a custom hex color or a site color variable.
 */
function appnet_fraud_alert_sanitize_color_source($value) {
	return $value === 'site' ? 'site' : 'custom';
}

/**
 * Sanitize the saved site color key.
 */
function appnet_fraud_alert_sanitize_site_color_key($value) {
	$options = appnet_fraud_alert_site_color_options();
	return isset($options[$value]) ? $value : '';
}

/**
 * Resolve a color setting into a CSS-safe value.
 *
 * Custom color output:
 * #111111
 *
 * Site color output:
 * var(--color-content-primary, #111111)
 */
function appnet_fraud_alert_get_css_color_value($settings, $key) {
	$defaults = appnet_fraud_alert_defaults();
	$options = appnet_fraud_alert_site_color_options();

	$fallback = appnet_fraud_alert_sanitize_color(
		$settings[$key] ?? $defaults[$key],
		$defaults[$key]
	);

	$source = $settings[$key . '_source'] ?? 'custom';
	$site_color_key = $settings[$key . '_site_color'] ?? '';

	if ($source === 'site' && isset($options[$site_color_key])) {
		return 'var(' . $options[$site_color_key]['css_var'] . ', ' . $fallback . ')';
	}

	return $fallback;
}

/**
 * Sanitize settings.
 */
function appnet_fraud_alert_sanitize_settings($input) {
	$defaults = appnet_fraud_alert_defaults();
	$input = is_array($input) ? $input : array();

	$output = array(
		'enabled' => isset($input['enabled']) ? '1' : '0',
		'bar_title' => sanitize_text_field($input['bar_title'] ?? $defaults['bar_title']),
		'bar_text' => sanitize_text_field($input['bar_text'] ?? $defaults['bar_text']),
		'button_text' => sanitize_text_field($input['button_text'] ?? $defaults['button_text']),
		'panel_title' => sanitize_text_field($input['panel_title'] ?? $defaults['panel_title']),
		'panel_content' => sanitize_textarea_field($input['panel_content'] ?? $defaults['panel_content']),
	);

	$color_keys = array(
		'bar_background_color',
		'bar_text_color',
		'button_background_color',
		'button_text_color',
		'panel_background_color',
		'panel_text_color',
		'close_button_background_color',
		'close_button_text_color',
		'panel_border_color',
	);

	foreach ($color_keys as $key) {
		$output[$key] = appnet_fraud_alert_sanitize_color($input[$key] ?? $defaults[$key], $defaults[$key]);
		$output[$key . '_site_color'] = appnet_fraud_alert_sanitize_site_color_key($input[$key . '_site_color'] ?? $defaults[$key . '_site_color']);

		/*
		 * v1.5.2 simplified the admin UI to a single dropdown:
		 * - blank site color = custom hex color
		 * - selected site color = Impreza / site color variable
		 *
		 * Keep the source value internally so older saved settings and frontend logic remain compatible.
		 */
		$output[$key . '_source'] = $output[$key . '_site_color'] !== '' ? 'site' : 'custom';
	}

	return $output;
}

/**
 * Render a color field.
 */
function appnet_fraud_alert_color_field($settings, $key, $label) {
	$source_key = $key . '_source';
	$site_color_key = $key . '_site_color';
	$source = $settings[$source_key] ?? 'custom';
	$site_color = $source === 'site' ? ($settings[$site_color_key] ?? '') : '';
	$site_color_options = appnet_fraud_alert_site_color_options();
	?>
	<tr>
		<th scope="row"><?php echo esc_html($label); ?></th>
		<td>
			<div class="appnet-alert-color-field">
				<label>
					<span class="screen-reader-text"><?php echo esc_html($label); ?> color selection</span>
					<select name="appnet_fraud_alert_settings[<?php echo esc_attr($site_color_key); ?>]" class="appnet-alert-site-color">
						<option value="" <?php selected($site_color, ''); ?>>Use custom color</option>
						<?php foreach ($site_color_options as $option_key => $option) : ?>
							<option value="<?php echo esc_attr($option_key); ?>" data-css-var="<?php echo esc_attr($option['css_var']); ?>" <?php selected($site_color, $option_key); ?>>
								<?php echo esc_html($option['label']); ?>
							</option>
						<?php endforeach; ?>
					</select>
				</label>

				<span class="appnet-alert-site-color-controls">
					<span class="appnet-alert-site-color-preview" aria-hidden="true" title="Selected site color preview"></span>
					<span class="appnet-alert-site-color-value code" aria-hidden="true"></span>
				</span>

				<span class="appnet-alert-custom-color-controls">
					<label>
						<span class="screen-reader-text"><?php echo esc_html($label); ?> custom color picker</span>
						<input type="color" class="appnet-alert-color-picker" name="appnet_fraud_alert_settings[<?php echo esc_attr($key); ?>]" value="<?php echo esc_attr($settings[$key]); ?>">
					</label>

					<label>
						<span class="screen-reader-text"><?php echo esc_html($label); ?> custom hex color</span>
						<input type="text" class="regular-text code appnet-alert-color-hex" name="appnet_fraud_alert_settings[<?php echo esc_attr($key); ?>]" value="<?php echo esc_attr($settings[$key]); ?>" pattern="^#[a-fA-F0-9]{6}$">
					</label>
				</span>
			</div>

		</td>
	</tr>
	<?php
}

/**
 * Render settings page.
 */
function appnet_fraud_alert_render_settings_page() {
	if (!current_user_can('manage_options')) return;

	$settings = appnet_fraud_alert_get_settings();
	?>
	<div class="wrap">
		<h1>Appnet Alert Bar</h1>

		<form method="post" action="options.php">
			<?php settings_fields('appnet_fraud_alert_group'); ?>

			<h2>Alert Content</h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row">Enable Alert</th>
					<td>
						<label>
							<input type="checkbox" name="appnet_fraud_alert_settings[enabled]" value="1" <?php checked($settings['enabled'], '1'); ?>>
							Show alert bar
						</label>
					</td>
				</tr>

				<tr>
					<th scope="row">Bar Title</th>
					<td>
						<input type="text" class="regular-text" name="appnet_fraud_alert_settings[bar_title]" value="<?php echo esc_attr($settings['bar_title']); ?>">
					</td>
				</tr>

				<tr>
					<th scope="row">Bar Text</th>
					<td>
						<input type="text" class="large-text" name="appnet_fraud_alert_settings[bar_text]" value="<?php echo esc_attr($settings['bar_text']); ?>">
					</td>
				</tr>

				<tr>
					<th scope="row">Button Text</th>
					<td>
						<input type="text" class="regular-text" name="appnet_fraud_alert_settings[button_text]" value="<?php echo esc_attr($settings['button_text']); ?>">
					</td>
				</tr>

				<tr>
					<th scope="row">Panel Title</th>
					<td>
						<input type="text" class="regular-text" name="appnet_fraud_alert_settings[panel_title]" value="<?php echo esc_attr($settings['panel_title']); ?>">
					</td>
				</tr>

				<tr>
					<th scope="row">Panel Content</th>
					<td>
						<textarea class="large-text" rows="12" name="appnet_fraud_alert_settings[panel_content]"><?php echo esc_textarea($settings['panel_content']); ?></textarea>
						<p class="description">Line breaks will be preserved on the front end.</p>
					</td>
				</tr>
			</table>

			<h2>Color Options</h2>
			<p>
				Each color can use a custom hex value or an Impreza / site color. Select “Use custom color” in a dropdown to show the color picker and hex field. The custom color is retained as the CSS fallback when a site color is selected.
			</p>

			<table class="form-table" role="presentation">
				<?php
				appnet_fraud_alert_color_field($settings, 'bar_background_color', 'Bar Background');
				appnet_fraud_alert_color_field($settings, 'bar_text_color', 'Bar Text');
				appnet_fraud_alert_color_field($settings, 'button_background_color', 'More Info Button Background');
				appnet_fraud_alert_color_field($settings, 'button_text_color', 'More Info Button Text');
				appnet_fraud_alert_color_field($settings, 'panel_background_color', 'Expanded Panel Background');
				appnet_fraud_alert_color_field($settings, 'panel_text_color', 'Expanded Panel Text');
				appnet_fraud_alert_color_field($settings, 'close_button_background_color', 'Close Button Background');
				appnet_fraud_alert_color_field($settings, 'close_button_text_color', 'Close Button Text');
				appnet_fraud_alert_color_field($settings, 'panel_border_color', 'Panel Bottom Border');
				?>
			</table>

			<?php submit_button(); ?>
		</form>
	</div>

	<style>
		.appnet-alert-color-field {
			display: flex;
			align-items: center;
			gap: 10px;
			flex-wrap: wrap;
		}

		.appnet-alert-color-field select {
			min-width: 250px;
		}

		.appnet-alert-custom-color-controls,
		.appnet-alert-site-color-controls {
			display: inline-flex;
			align-items: center;
			gap: 10px;
		}

		.appnet-alert-color-field .appnet-alert-color-hex {
			width: 110px;
		}

		.appnet-alert-color-field.is-site-color .appnet-alert-custom-color-controls {
			display: none;
		}

		.appnet-alert-color-field:not(.is-site-color) .appnet-alert-site-color-controls {
			display: none;
		}

		.appnet-alert-site-color-preview {
			display: inline-block;
			width: 24px;
			height: 24px;
			border: 1px solid #8c8f94;
			border-radius: 3px;
			box-shadow: inset 0 0 0 1px rgba(255,255,255,0.35);
			background: transparent;
			vertical-align: middle;
		}

		.appnet-alert-site-color-preview.is-loading {
			background-image: linear-gradient(45deg, rgba(0,0,0,.08) 25%, transparent 25%, transparent 50%, rgba(0,0,0,.08) 50%, rgba(0,0,0,.08) 75%, transparent 75%, transparent);
			background-size: 10px 10px;
		}

		.appnet-alert-site-color-value {
			font-size: 12px;
			color: #646970;
			min-width: 150px;
		}
	</style>

	<script>
		document.addEventListener('DOMContentLoaded', function () {
			const frontendUrl = <?php echo wp_json_encode(home_url('/')); ?>;
			let frontendComputedStyles = null;
			let frontendStylesLoaded = false;

			function getSelectedOption(select) {
				return select && select.options ? select.options[select.selectedIndex] : null;
			}

			function getResolvedThemeColor(cssVarName, fallback) {
				if (!cssVarName) return fallback;

				if (frontendComputedStyles) {
					const frontendValue = frontendComputedStyles.getPropertyValue(cssVarName).trim();
					if (frontendValue) return frontendValue;
				}

				const adminValue = window.getComputedStyle(document.documentElement).getPropertyValue(cssVarName).trim();
				if (adminValue) return adminValue;

				return fallback;
			}

			function updateColorField(field) {
				const siteColor = field.querySelector('.appnet-alert-site-color');
				const swatch = field.querySelector('.appnet-alert-site-color-preview');
				const valueLabel = field.querySelector('.appnet-alert-site-color-value');
				const picker = field.querySelector('.appnet-alert-color-picker');
				const hex = field.querySelector('.appnet-alert-color-hex');

				if (!siteColor || !swatch || !valueLabel || !picker || !hex) return;

				const option = getSelectedOption(siteColor);
				const cssVarName = option ? option.getAttribute('data-css-var') : '';
				const fallback = /^#[a-fA-F0-9]{6}$/.test(hex.value) ? hex.value : picker.value;
				const usingSiteColor = Boolean(siteColor.value && cssVarName);
				const previewColor = usingSiteColor ? getResolvedThemeColor(cssVarName, fallback) : fallback;

				field.classList.toggle('is-site-color', usingSiteColor);
				swatch.style.background = previewColor;
				swatch.classList.toggle('is-loading', usingSiteColor && !frontendStylesLoaded);
				valueLabel.textContent = usingSiteColor ? cssVarName + ' → ' + previewColor : '';
				valueLabel.title = usingSiteColor ? 'Uses ' + cssVarName + ' with ' + fallback + ' as fallback' : '';
			}

			function updateAllColorFields() {
				document.querySelectorAll('.appnet-alert-color-field').forEach(updateColorField);
			}

			document.querySelectorAll('.appnet-alert-color-field').forEach(function (field) {
				const picker = field.querySelector('.appnet-alert-color-picker');
				const hex = field.querySelector('.appnet-alert-color-hex');
				const siteColor = field.querySelector('.appnet-alert-site-color');

				if (!picker || !hex) return;

				picker.addEventListener('input', function () {
					hex.value = picker.value;
					updateColorField(field);
				});

				hex.addEventListener('input', function () {
					if (/^#[a-fA-F0-9]{6}$/.test(hex.value)) {
						picker.value = hex.value;
					}
					updateColorField(field);
				});

				if (siteColor) siteColor.addEventListener('change', function () { updateColorField(field); });

				updateColorField(field);
			});

			/*
			 * Impreza usually defines these CSS variables on the front end, not necessarily inside wp-admin.
			 * Load the homepage in a hidden same-origin iframe so the previews can read the actual live site colors.
			 */
			const iframe = document.createElement('iframe');
			iframe.src = frontendUrl;
			iframe.setAttribute('aria-hidden', 'true');
			iframe.tabIndex = -1;
			iframe.style.position = 'absolute';
			iframe.style.left = '-99999px';
			iframe.style.width = '1px';
			iframe.style.height = '1px';
			iframe.style.opacity = '0';
			iframe.style.pointerEvents = 'none';

			iframe.addEventListener('load', function () {
				try {
					frontendComputedStyles = iframe.contentWindow.getComputedStyle(iframe.contentDocument.documentElement);
					frontendStylesLoaded = true;
					updateAllColorFields();
				} catch (error) {
					frontendStylesLoaded = true;
					updateAllColorFields();
				}
			});

			document.body.appendChild(iframe);
		});
	</script>
	<?php
}

/**
 * Render alert at the top of the site.
 */
function appnet_fraud_alert_render_frontend() {
	$settings = appnet_fraud_alert_get_settings();

	if ($settings['enabled'] !== '1') {
		return;
	}
	?>
	<div class="appnet-fraud-alert-bar" role="region" aria-label="Site alert">
		<strong><?php echo esc_html($settings['bar_title']); ?></strong>
		<span><?php echo esc_html($settings['bar_text']); ?></span>
		<button type="button" class="appnet-fraud-alert-toggle">
			<?php echo esc_html($settings['button_text']); ?>
		</button>
	</div>

	<div class="appnet-fraud-alert-panel" hidden>
		<div class="appnet-fraud-alert-panel-inner">
			<button type="button" class="appnet-fraud-alert-close">Close</button>

			<h2><?php echo esc_html($settings['panel_title']); ?></h2>

			<div class="appnet-fraud-alert-content">
				<?php echo wpautop(esc_html($settings['panel_content'])); ?>
			</div>
		</div>
	</div>
	<?php
}
add_action('wp_body_open', 'appnet_fraud_alert_render_frontend');

/**
 * Frontend CSS and JS.
 */
function appnet_fraud_alert_frontend_assets() {
	$settings = appnet_fraud_alert_get_settings();

	if ($settings['enabled'] !== '1') {
		return;
	}
	?>
	<style>
		:root {
			--appnet-alert-bar-bg: <?php echo esc_attr(appnet_fraud_alert_get_css_color_value($settings, 'bar_background_color')); ?>;
			--appnet-alert-bar-text: <?php echo esc_attr(appnet_fraud_alert_get_css_color_value($settings, 'bar_text_color')); ?>;
			--appnet-alert-button-bg: <?php echo esc_attr(appnet_fraud_alert_get_css_color_value($settings, 'button_background_color')); ?>;
			--appnet-alert-button-text: <?php echo esc_attr(appnet_fraud_alert_get_css_color_value($settings, 'button_text_color')); ?>;
			--appnet-alert-panel-bg: <?php echo esc_attr(appnet_fraud_alert_get_css_color_value($settings, 'panel_background_color')); ?>;
			--appnet-alert-panel-text: <?php echo esc_attr(appnet_fraud_alert_get_css_color_value($settings, 'panel_text_color')); ?>;
			--appnet-alert-close-bg: <?php echo esc_attr(appnet_fraud_alert_get_css_color_value($settings, 'close_button_background_color')); ?>;
			--appnet-alert-close-text: <?php echo esc_attr(appnet_fraud_alert_get_css_color_value($settings, 'close_button_text_color')); ?>;
			--appnet-alert-panel-border: <?php echo esc_attr(appnet_fraud_alert_get_css_color_value($settings, 'panel_border_color')); ?>;
		}

		.appnet-fraud-alert-bar {
			width: 100%;
			background: var(--appnet-alert-bar-bg);
			color: var(--appnet-alert-bar-text);
			padding: 12px 24px;
			font-size: 15px;
			line-height: 1.4;
			display: flex;
			align-items: center;
			justify-content: center;
			gap: 14px;
			flex-wrap: wrap;
			z-index: 9000;
			position: relative;
			box-sizing: border-box;
			text-align: center;
			overflow: hidden;
			max-height: 220px;
			transition: max-height 0.2s ease, padding 0.2s ease, opacity 0.2s ease;
		}

		.appnet-fraud-alert-bar strong {
			font-weight: 700;
			color: inherit;
		}

		.appnet-fraud-alert-toggle,
		.appnet-fraud-alert-close {
			background: var(--appnet-alert-button-bg);
			color: var(--appnet-alert-button-text);
			border: 0;
			padding: 7px 14px;
			cursor: pointer;
			font-weight: 600;
			border-radius: 0;
			line-height: 1.3;
		}

		.appnet-fraud-alert-toggle:hover,
		.appnet-fraud-alert-close:hover {
			opacity: 0.85;
		}

		/**
		 * When the user scrolls down, collapse the actual alert bar.
		 * This lets the header move up naturally without fake padding/margins.
		 */
		body.appnet-fraud-alert-scrolled .appnet-fraud-alert-bar {
			max-height: 0;
			padding-top: 0;
			padding-bottom: 0;
			opacity: 0;
			pointer-events: none;
		}

		.appnet-fraud-alert-panel {
			background: var(--appnet-alert-panel-bg);
			color: var(--appnet-alert-panel-text);
			padding: 40px 24px;
			border-bottom: 1px solid var(--appnet-alert-panel-border);
			z-index: 8990;
			position: relative;
			box-sizing: border-box;
		}

		.appnet-fraud-alert-panel-inner {
			max-width: 1100px;
			margin: 0 auto;
		}

		.appnet-fraud-alert-panel h2 {
			margin-top: 0;
			margin-bottom: 24px;
			color: inherit;
		}

		.appnet-fraud-alert-close {
			float: right;
			background: var(--appnet-alert-close-bg);
			color: var(--appnet-alert-close-text);
			margin-left: 20px;
			margin-bottom: 20px;
		}

		.appnet-fraud-alert-content {
			clear: both;
		}

		/**
		 * When More Info is open, hide the normal alert bar.
		 */
		body.appnet-fraud-alert-open .appnet-fraud-alert-bar {
			display: none !important;
		}

		@media (max-width: 600px) {
			.appnet-fraud-alert-bar {
				display: block;
				padding: 12px 16px;
			}

			.appnet-fraud-alert-bar strong,
			.appnet-fraud-alert-bar span {
				display: block;
				margin-bottom: 8px;
			}

			body.appnet-fraud-alert-scrolled .appnet-fraud-alert-bar {
				padding-top: 0;
				padding-bottom: 0;
			}

			.appnet-fraud-alert-panel {
				padding: 30px 18px;
			}

			.appnet-fraud-alert-close {
				float: none;
				display: inline-block;
				margin: 0 0 20px 0;
			}
		}
	</style>

	<script>
		document.addEventListener('DOMContentLoaded', function () {
			const toggle = document.querySelector('.appnet-fraud-alert-toggle');
			const close = document.querySelector('.appnet-fraud-alert-close');
			const panel = document.querySelector('.appnet-fraud-alert-panel');

			if (!toggle || !close || !panel) return;

			let scrollTimer = null;

			function collapseFraudAlert() {
				document.body.classList.add('appnet-fraud-alert-scrolled');
			}

			function showFraudAlert() {
				document.body.classList.remove('appnet-fraud-alert-scrolled');
			}

			function updateFraudAlertScrollState() {
				if (document.body.classList.contains('appnet-fraud-alert-open')) {
					return;
				}

				clearTimeout(scrollTimer);

				/*
				 * Collapse only after the user has clearly moved down the page.
				 * This avoids the alert rapidly opening/closing near the top.
				 */
				if (window.scrollY > 80) {
					collapseFraudAlert();
					return;
				}

				/*
				 * Only reopen when the user is truly at the top, and wait briefly
				 * so it does not fight against normal scrolling momentum.
				 */
				if (window.scrollY <= 0) {
					scrollTimer = setTimeout(function () {
						if (window.scrollY <= 0 && !document.body.classList.contains('appnet-fraud-alert-open')) {
							showFraudAlert();
						}
					}, 150);
				}
			}

			updateFraudAlertScrollState();

			window.addEventListener('scroll', updateFraudAlertScrollState, { passive: true });

			toggle.addEventListener('click', function () {
				panel.hidden = false;

				document.body.classList.add('appnet-fraud-alert-open');
				document.body.classList.remove('appnet-fraud-alert-scrolled');

				window.scrollTo({ top: 0, behavior: 'auto' });
			});

			close.addEventListener('click', function () {
				panel.hidden = true;

				document.body.classList.remove('appnet-fraud-alert-open');

				updateFraudAlertScrollState();
			});
		});
	</script>
	<?php
}
add_action('wp_footer', 'appnet_fraud_alert_frontend_assets');
